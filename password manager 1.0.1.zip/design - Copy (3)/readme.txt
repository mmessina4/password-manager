1.0.1

Changes-
Login page sorta implemented
Needs to hide elements properly
