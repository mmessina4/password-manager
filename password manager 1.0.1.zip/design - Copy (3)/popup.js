// Initialize butotn with users's prefered color
//let changeColor = document.getElementById("changeColor");

//chrome.storage.sync.get("color", ({ color }) => {
//  changeColor.style.backgroundColor = color;
//});

// When the button is clicked, inject setPageBackgroundColor into current page
//changeColor.addEventListener("click", async () => {
  //let [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

 // chrome.scripting.executeScript({
 //   target: { tabId: tab.id },
 //   function: setPageBackgroundColor,
 // });
//});

// The body of this function will be execuetd as a content script inside the
// current page
function turnOnOff() {
  var x = document.getElementById("userPanel");
  if (x.style.display === "none") {
    x.style.display = "block";
  } else {
    x.style.display = "none";
  }
}
  


function setPageBackgroundColor() {
    chrome.storage.sync.get("color", ({ color }) => {
      document.body.style.backgroundColor = color;
    });
  
   
  }
  
  
  function addressFunction() {
    if (document.getElementById(
      "same").checked) {
        document.getElementById(
          "secondaryaddress").value = 
        document.getElementById(
          "username").value;
        
        document.getElementById(
          "secondaryzip").value = 
        document.getElementById(
          "primaryzip").value;
    } else {
        document.getElementById(
          "secondaryaddress").value = "";
        document.getElementById(
          "secondaryzip").value = "";
    }
  }
  
  
  
  
  
  
  
  
  
  
  
  

  
  
  
  console.log("Hello");
  //console.log('username is ' + value);
  
  /*
  document.body.onload = function() {
    chrome.storage.sync.get("data", function(items) {
      if (!chrome.runtime.error) {
        console.log(items);
        document.getElementById("data").innerText = items.data;
      }
    });
  }
  
  document.getElementById("set").onclick = function() {
    var d = document.getElementById("text").value;
    chrome.storage.sync.set({ "data" : d }, function() {
      if (chrome.runtime.error) {
        console.log("Runtime error.");
      }
    });
    window.close();
  }
  /*
  */
   